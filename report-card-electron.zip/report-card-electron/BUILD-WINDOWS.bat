@echo off
setlocal
cd /d "%~dp0"
echo Installing Electron dependencies...
npm install
if errorlevel 1 goto :error
echo.
echo Building Windows installer...
npm run dist
if errorlevel 1 goto :error
echo.
echo BUILD COMPLETE. Your installer is in the dist folder.
pause
exit /b 0
:error
echo.
echo BUILD FAILED. Check the error message above.
pause
exit /b 1
